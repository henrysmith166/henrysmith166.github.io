﻿using System;
using System.ComponentModel;
using System.Security.Cryptography;
using System.Xml.Linq;
using System.Diagnostics;

namespace TSPGUI
{
    public static class TSP
    {


        #region CLI
        //public static Dictionary<string, Dictionary<string, float>> GenerateRandomTSPGraph(int nodeCount)
        //{
        //    var graph = new Dictionary<string, Dictionary<string, float>>();
        //    var nodeNames = new List<string>();

        //    // Generate unique node names A–Z, then A1, B1, etc. if needed
        //    for (int i = 0; i < nodeCount; i++)
        //    {
        //        if (i < 26)
        //            nodeNames.Add(((char)('A' + i)).ToString());
        //        else
        //            nodeNames.Add(((char)('A' + (i % 26))).ToString() + (i / 26));
        //    }

        //    // Initialize all nodes
        //    foreach (var name in nodeNames)
        //        graph[name] = new Dictionary<string, float>();

        //    var rand = new Random();

        //    // Fill graph with random distances and ensure symmetry
        //    for (int i = 0; i < nodeCount; i++)
        //    {
        //        for (int j = i + 1; j < nodeCount; j++)
        //        {
        //            float dist = (float)Math.Round(rand.NextDouble() * 9 + 1, 1); // 1.0 to 10.0
        //            graph[nodeNames[i]][nodeNames[j]] = dist;
        //            graph[nodeNames[j]][nodeNames[i]] = dist;
        //        }
        //    }

        //    return graph;
        //}

        //public static Dictionary<string, Dictionary<string, float>> AcceptNodes()
        //{
        //    var nodes = new Dictionary<string, Dictionary<string, float>>();

        //    while (true)
        //    {
        //        Console.Write("Input new node name or type !escape to exit: ");
        //        string? newNodeName = Console.ReadLine();
        //        if (string.IsNullOrWhiteSpace(newNodeName))
        //        {
        //            Console.WriteLine("Node name cannot be empty. Try again.");
        //            continue;
        //        }

        //        if (newNodeName == "!escape") break;

        //        if (nodes.Count >= 25)
        //        {
        //            Console.WriteLine("Node limit reached. Cannot add more.");
        //            break;
        //        }

        //        if (nodes.ContainsKey(newNodeName))
        //        {
        //            Console.WriteLine("This node already exists. Try again.");
        //            continue;
        //        }

        //        var connections = new Dictionary<string, float>();

        //        while (connections.Count == 0)
        //        {
        //            Console.WriteLine($"Add at least one connection for {newNodeName}");

        //            while (true)
        //            {
        //                Console.Write("Input contacted node name or type !done to finish: ");
        //                string? contactedNodeName = Console.ReadLine();

        //                if (string.IsNullOrWhiteSpace(contactedNodeName))
        //                {
        //                    Console.WriteLine("Contacted node name cannot be empty. Try again.");
        //                    continue;
        //                }

        //                if (contactedNodeName == "!done")
        //                {
        //                    if (connections.Count == 0)
        //                    {
        //                        Console.WriteLine("You must add at least one connection.");
        //                        continue;
        //                    }
        //                    break;
        //                }

        //                Console.Write($"Input distance from {newNodeName} to {contactedNodeName}: ");
        //                if (!float.TryParse(Console.ReadLine(), out float distance) || distance < 0)
        //                {
        //                    Console.WriteLine("Invalid distance. Please enter a positive integer.");
        //                    continue;
        //                }

        //                connections[contactedNodeName] = distance;
        //            }
        //        }

        //        nodes[newNodeName] = connections;
        //        Console.WriteLine($"Node {newNodeName} added with {connections.Count} connections.");
        //    }




        //    return nodes;
        //}
        #endregion


        public static Dictionary<string, float> Dijkstra(Dictionary<string, Dictionary<string, float>> graph, string start)
        {
            Dictionary<string, float> distances = new Dictionary<string, float>();

            foreach (var node in graph.Keys)
            {
                distances[node] = float.PositiveInfinity;
            }

            distances[start] = 0;

            PriorityQueue<string, float> pq = new PriorityQueue<string, float>();
            pq.Enqueue(start, 0);

            var visited = new HashSet<string>(); // Hashset for O(1) lookup instead of list.Contains at O(n)


            while (pq.Count > 0)
            {
#pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.
                pq.TryDequeue(out string currentNode, out float currentDistance); // TryDequeue because Dequeue just returns element not priority
#pragma warning restore CS8600 // Converting null literal or possible null value to non-nullable type.

#pragma warning disable CS8604 // Possible null reference argument.
                if (visited.Contains(currentNode)) continue; // already finalized this node? if so, skip
#pragma warning restore CS8604 // Possible null reference argument.
                visited.Add(currentNode); // mark as processed

                foreach (var neighbor in graph[currentNode]) // check all edges on this node
                {
                    string neighborNode = neighbor.Key;
                    float edgeWeight = neighbor.Value;

                    float newDist = currentDistance + edgeWeight; // proposed shortest distance to neighbor

                    if (newDist < distances[neighborNode]) // rte shorter than old?
                    {
                        distances[neighborNode] = newDist;
                        pq.Enqueue(neighborNode, newDist); // explore later
                    }
                }
            }
            return distances;
        }



        
        public static float[,] DistanceMatrixForSubset(Dictionary<string, Dictionary<string, float>> fullGraph, List<string> subset, out List<string> nodeList) // sq distance matrix to rebuild full path 
        {
            nodeList = subset;
            int n = subset.Count;
            float[,] m = new float[n, n]; // m[i,j] = shortest path from subset[i] > subset[j]

            for (int i = 0; i < n; i++) // i/j = index of from/to
            {
                var d = Dijkstra(fullGraph, subset[i]); // full graph here
                for (int j = 0; j < n; j++)
                    m[i, j] = d[subset[j]]; // in case of multi-hop (no direct edge)
            }
            return m;
        }




        public static float[,] DistanceMatrix(Dictionary<string, Dictionary<string, float>> graph, out List<string> nodeList)
        {
            nodeList = graph.Keys.ToList(); // ordered list of node names to allow conversion between node name and index
            int nodeCount = nodeList.Count;
            float[,] distMatrix = new float[nodeCount, nodeCount]; // build square matrix with count of nodes as length of side
            // e.g. if nodeList = ["A", "B", "C"] then distMatrix[0, 1] = cost from A to B, distMatrix[2, 0] = cost from C to A

            for (int nodeIndex = 0; nodeIndex < nodeCount; nodeIndex++)
            {
                string fromNode = nodeList[nodeIndex]; // convert index to name to run dijkstra
                var distances = Dijkstra(graph, fromNode); // run dijkstra from current node

                for (int destinationIndex = 0; destinationIndex < nodeCount; destinationIndex++)
                {
                    string toNode = nodeList[destinationIndex];
                    float distance = distances[toNode];

                    if (float.IsPositiveInfinity(distance))
                    {
                        // should never happen! just a catch :)
                        distance = float.MaxValue;
                    }

                    distMatrix[nodeIndex, destinationIndex] = distance; // store shortest path from nodeIndex to destinationIndex
                }
            }

            return distMatrix;
        }

        public static (float cost, List<int> path) HeldKarp(float[,] distMatrix)
        {
            int nodeCount = distMatrix.GetLength(0); // num of rows = node count

            int[,] parent = new int[1 << nodeCount, nodeCount]; // parent[x, y] = the previous node used to reach node y with visited set x (bitmask)
            for (int i = 0; i<(1<<nodeCount); i++)
            {
                for (int j = 0; j<nodeCount;  j++)
                {
                    parent[i, j] = -25; // again, these should all disappear but just in case, -25 is a very weird number and we should catch it.
                }
            }


            float[,] dp = new float[1 << nodeCount, nodeCount]; // creates matrix (2^nodecount by nodecount). 
                                                                // EXAMPLE: dp[5,2] = 10.2 ----- bitmask = 5, 5 = 0101, nodes 0 and 2 have been visited (read r>l), end node = 2, cost of route = 10.2


            for (int i = 0; i < (1 << nodeCount); i++)
                for (int j = 0; j < nodeCount; j++)
                    dp[i, j] = float.PositiveInfinity;
            // initialize all cells of dp to posinf to prevent a > b > a as best path

            dp[1 << 0, 0] = 0f; // base case, only node 0 is visited (1 << 0 = 0001), and we are already at node 0 qed cost = 0
            int prev = 0;
            for (int mask = 0; mask < (1 << nodeCount); mask++) // terminates at 2^nodecount - 1, aka 2^n-1 all nodes visited
            {

                if (mask % 1000000 == 0)
                    Console.WriteLine($"Processing mask {mask} of {(1 << nodeCount)}");

                for (int current = 0; current < nodeCount; current++)
                {
                    if ((mask & (1 << current)) == 0) continue; // node has not been visited yet, skip.

                    for (prev = 0; prev < nodeCount; prev++) // find sequence of previous nodes, cheapest route to where we are - prev just sets up the m & (1 << prev) later
                    {
                        if (prev == current || (mask & (1 << prev)) == 0) continue; // cant come from current node, bitwise and to check 1 is at position of prev in mask



                        float candidate = dp[mask ^ (1 << current), prev] + distMatrix[prev, current]; // mask^(1<<current) removes current from mask, dp[m^(1<<c),prev] returns best
                                                                                                       // cost to prev after all except current, + distmatrix[p,c] to get to current

                        if (candidate < dp[mask, current]) // finding the minimum cost to get here, current best cost vs candidate better
                        {
                            dp[mask, current] = candidate;
                            parent[mask, current] = prev; // update parent node to the current previous node
                        }
                    }
                }
            }

            int fullMask = (1 << nodeCount) - 1; // fullMask = 2^n-1
            float minTourCost = float.PositiveInfinity;
            int lastNode = -1;

            for (int i = 1; i < nodeCount; i++) // i = 1 because cant return to node 0 before ever leaving it
            {
                if (float.IsPositiveInfinity(dp[fullMask, i]) || distMatrix[i, 0] == float.MaxValue)
                    continue;
                float cost = dp[fullMask, i] + distMatrix[i, 0]; // cost to visit all nodes and end at i + cost to get from i -> start
                if (cost < minTourCost)
                {
                    minTourCost = cost;
                    lastNode = i; // if its better update it and last node of path
                }
            }
            if (lastNode == -1)
            {
                MessageBox.Show("Failed with no valid path");
                throw new InvalidOperationException("No valid tour.");
            }

            List<int> path = new();
            int mask2 = fullMask;
            int current2 = lastNode;
            
            while (current2 != 0) // while not at start
            {
                path.Add(current2); // add current node to path
                try
                {
                    int rows = parent.GetLength(0);
                    int cols = parent.GetLength(1);

                    File.AppendAllText("error_log.txt", $"Attempting access: parent[{mask2}, {current2}]\n");
                    File.AppendAllText("error_log.txt", $"Bounds: rows = {rows}, cols = {cols}\n");

                    if (mask2 < 0 || mask2 >= rows || current2 < 0 || current2 >= cols)
                    {
                        File.AppendAllText("error_log.txt", $"Access out of bounds.\n");
                        throw new IndexOutOfRangeException($"parent[{mask2}, {current2}] is out of bounds.");
                    }

                    prev = parent[mask2, current2]; // Line 261
                }
                catch (Exception ex)
                {
                    File.AppendAllText("error_log.txt", $"Exception: {ex.GetType()}\nMessage: {ex.Message}\nStackTrace: {ex.StackTrace}\n");
                    throw;
                }
                // find best parent node as calculated above
                mask2 ^= (1 << current2); // unvisit current
                current2 = prev;
            }


            if (lastNode == -1)
            {
                // Nothing forms a Hamiltonian cycle that comes back to depot 0
                throw new InvalidOperationException(
                    "The chosen set of depots is not fully connected – " +
                    "no tour visiting every depot and returning to the start exists.");
            }


            path.Add(0); // add start
            path.Reverse(); // path start -> end instead of backwards
            path.Add(0); // complete the cycle

            Console.WriteLine("Raw path (indices): " + string.Join(", ", path));


            return (minTourCost, path);
        }




        public static (Dictionary<string, float> distances, Dictionary<string, string?> parents) DijkstraWithParents(Dictionary<string, Dictionary<string, float>> graph, string start) // also records prev so can rebuild
        {
            var distances = new Dictionary<string, float>();
            var parents = new Dictionary<string, string?>();

            foreach (var node in graph.Keys)
            {
                distances[node] = float.PositiveInfinity;
                parents[node] = null;
            }
            distances[start] = 0f;

            var pq = new PriorityQueue<string, float>();
            pq.Enqueue(start, 0);

            HashSet<string> visited = new HashSet<string>();

            while (pq.Count > 0)
            {
                pq.TryDequeue(out string currentNode, out float currentDistance);

                if (visited.Contains(currentNode)) continue;
                visited.Add(currentNode);

                foreach (var (node, cost) in graph[currentNode])
                {
                    float candidate = currentDistance + cost;
                    if (candidate < distances[node])
                    {
                        distances[node] = candidate;
                        parents[node] = currentNode; // literal only difference to Dijkstra(), just tracks the parents. probably shouldve done this before but oh well
                        pq.Enqueue(node, candidate);
                    }
                }
            }
            return (distances, parents);
        }


        public static List<string> ReconstructPath(Dictionary<string, string?> parents, string from, string to)
        {
            var path = new List<string>();
            string? current = to;

            while (current != null)
            {
                path.Add(current);
                if (current == from) break; //                                                                            break
                current = parents[current]; // steps through the parents for each current until nothing left in which case ^
            }

            path.Reverse(); // now runs from 'from' to 'to'
            if (path[0] != from) // no route existed - just a guard
                throw new InvalidOperationException(
                    $"No path between {from} and {to} in the underlying graph.");

            return path;
        }


        public static List<string> ExpandTour( // may pass into unticked cities!
                List<int> tourIdx,  // indices from Held‑Karp
                List<string> depots, // depot names (usedNodeList)
                Dictionary<string, Dictionary<string, float>> fullGraph)
        {
            var fullRoute = new List<string>(); 

            for (int k = 0; k < tourIdx.Count - 1; k++)
            {
                string from = depots[tourIdx[k]]; // current
                string to = depots[tourIdx[k + 1]]; // next

                var (dist, parent) = DijkstraWithParents(fullGraph, from); // dijkstra w parents to figure how we got here
                var leg = ReconstructPath(parent, from, to); // reconstructs how we got here

                if (k > 0) leg.RemoveAt(0); // drop duplicate junction
                fullRoute.AddRange(leg);
            }
            return fullRoute;
        }


    }
}