﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows.Forms;
using TSPGUI;


namespace TSPGUI
{
    public partial class Form1 : Form
    {
        private Button btnSolve;
        private ComboBox cmbStartDepot;
        private CheckedListBox lstDepots;
        private TextBox txtOutput;

        private Dictionary<string, Dictionary<string, float>> graph = new Dictionary<string, Dictionary<string, float>>
        {
            ["[France] Lyon Node"] = new() { ["[Italy] Turin Storage"] = 3.46f, ["[France] Marseille Terminal"] = 3.82f, ["[Italy] Milan Depot"] = 4.77f, ["[Switzerland] Zurich Station"] = 4.98f, ["[France] Paris HQ"] = 6.61f },
            ["[Germany] Munich Hub"] = new() { ["[Switzerland] Zurich Station"] = 3.49f, ["[Czechia] Prague Unit"] = 5.08f, ["[Italy] Milan Depot"] = 5.16f, ["[Austria] Vienna Yard"] = 5.95f, ["[Italy] Turin Storage"] = 6.7f },
            ["[Netherlands] Amsterdam Dock"] = new() { ["[Belgium] Brussels Station"] = 2.46f, ["[Germany] Hamburg Port"] = 5.24f, ["[UK] London Base"] = 5.27f, ["[France] Paris HQ"] = 6.19f, ["[UK] Birmingham Facility"] = 6.64f },
            ["[Italy] Rome Dispatch"] = new() { ["[Italy] Milan Depot"] = 8.12f, ["[France] Marseille Terminal"] = 8.87f, ["[Italy] Turin Storage"] = 8.92f, ["[Switzerland] Zurich Station"] = 10.83f, ["[Austria] Vienna Yard"] = 11.26f },
            ["[Denmark] Copenhagen Hub"] = new() { ["[Germany] Hamburg Port"] = 3.96f, ["[Germany] Berlin Yard"] = 5.13f, ["[Norway] Oslo Gate"] = 7.24f, ["[Sweden] Stockholm Node"] = 7.33f, ["[Netherlands] Amsterdam Dock"] = 8.64f },
            ["[Spain] Barcelona Link"] = new() { ["[France] Marseille Terminal"] = 4.94f, ["[Spain] Madrid Central"] = 7.33f, ["[France] Lyon Node"] = 8.38f, ["[Italy] Turin Storage"] = 10.33f, ["[Italy] Milan Depot"] = 11.77f },
            ["[Poland] Warsaw Supply"] = new() { ["[Poland] Krakow Logistics"] = 3.6f, ["[Germany] Berlin Yard"] = 7.03f, ["[Czechia] Prague Unit"] = 7.2f, ["[Austria] Vienna Yard"] = 7.86f, ["[Denmark] Copenhagen Hub"] = 9.93f },
            ["[Italy] Turin Storage"] = new() { ["[Italy] Milan Depot"] = 1.78f, ["[France] Lyon Node"] = 3.52f, ["[France] Marseille Terminal"] = 3.73f, ["[Switzerland] Zurich Station"] = 3.75f, ["[Germany] Munich Hub"] = 6.37f },
            ["[Sweden] Stockholm Node"] = new() { ["[Norway] Oslo Gate"] = 5.78f, ["[Denmark] Copenhagen Hub"] = 7.45f, ["[Germany] Hamburg Port"] = 11.36f, ["[Poland] Warsaw Supply"] = 11.87f, ["[Germany] Berlin Yard"] = 12.14f },
            ["[UK] Manchester Hub"] = new() { ["[UK] Birmingham Facility"] = 1.67f, ["[Ireland] Dublin Store"] = 3.79f, ["[UK] London Base"] = 3.88f, ["[Netherlands] Amsterdam Dock"] = 7.09f, ["[Belgium] Brussels Station"] = 7.88f },
            ["[Germany] Hamburg Port"] = new() { ["[Germany] Berlin Yard"] = 3.75f, ["[Denmark] Copenhagen Hub"] = 4.29f, ["[Netherlands] Amsterdam Dock"] = 5.45f, ["[Czechia] Prague Unit"] = 6.79f, ["[Belgium] Brussels Station"] = 7.03f },
            ["[UK] London Base"] = new() { ["[UK] Birmingham Facility"] = 2.32f, ["[UK] Manchester Hub"] = 3.75f, ["[Belgium] Brussels Station"] = 4.77f, ["[Netherlands] Amsterdam Dock"] = 5.06f, ["[France] Paris HQ"] = 5.14f },
            ["[Austria] Vienna Yard"] = new() { ["[Czechia] Prague Unit"] = 3.56f, ["[Poland] Krakow Logistics"] = 4.72f, ["[Germany] Munich Hub"] = 4.84f, ["[Poland] Warsaw Supply"] = 7.59f, ["[Germany] Berlin Yard"] = 7.84f },
            ["[Spain] Madrid Central"] = new() { ["[Spain] Barcelona Link"] = 6.95f, ["[Portugal] Lisbon Center"] = 7.05f, ["[France] Marseille Terminal"] = 12.1f, ["[France] Paris HQ"] = 14.51f, ["[France] Lyon Node"] = 15.47f },
            ["[Poland] Krakow Logistics"] = new() { ["[Poland] Warsaw Supply"] = 3.54f, ["[Austria] Vienna Yard"] = 4.62f, ["[Czechia] Prague Unit"] = 5.79f, ["[Germany] Berlin Yard"] = 7.26f, ["[Germany] Munich Hub"] = 8.99f },
            ["[Ireland] Dublin Store"] = new() { ["[UK] Manchester Hub"] = 3.84f, ["[UK] Birmingham Facility"] = 4.27f, ["[UK] London Base"] = 6.82f, ["[Netherlands] Amsterdam Dock"] = 10.44f, ["[France] Paris HQ"] = 11.27f },
            ["[Belgium] Brussels Station"] = new() { ["[Netherlands] Amsterdam Dock"] = 2.35f, ["[France] Paris HQ"] = 3.6f, ["[UK] London Base"] = 4.72f, ["[Switzerland] Zurich Station"] = 6.78f, ["[UK] Birmingham Facility"] = 6.89f },
            ["[UK] Birmingham Facility"] = new() { ["[UK] Manchester Hub"] = 1.64f, ["[UK] London Base"] = 2.33f, ["[Ireland] Dublin Store"] = 4.4f, ["[Netherlands] Amsterdam Dock"] = 6.66f, ["[Belgium] Brussels Station"] = 6.93f },
            ["[Czechia] Prague Unit"] = new() { ["[Austria] Vienna Yard"] = 3.68f, ["[Germany] Munich Hub"] = 4.08f, ["[Germany] Berlin Yard"] = 4.18f, ["[Poland] Krakow Logistics"] = 5.78f, ["[Germany] Hamburg Port"] = 7.23f },
            ["[France] Paris HQ"] = new() { ["[Belgium] Brussels Station"] = 3.75f, ["[UK] London Base"] = 4.87f, ["[France] Lyon Node"] = 5.36f, ["[Netherlands] Amsterdam Dock"] = 6.31f, ["[Switzerland] Zurich Station"] = 6.94f },
            ["[Germany] Berlin Yard"] = new() { ["[Germany] Hamburg Port"] = 3.81f, ["[Czechia] Prague Unit"] = 3.86f, ["[Denmark] Copenhagen Hub"] = 5.24f, ["[Germany] Munich Hub"] = 7.08f, ["[Austria] Vienna Yard"] = 7.11f },
            ["[Italy] Milan Depot"] = new() { ["[Italy] Turin Storage"] = 1.81f, ["[Switzerland] Zurich Station"] = 3.1f, ["[France] Lyon Node"] = 4.76f, ["[Germany] Munich Hub"] = 5.19f, ["[France] Marseille Terminal"] = 5.52f },
            ["[France] Marseille Terminal"] = new() { ["[Italy] Turin Storage"] = 4.27f, ["[France] Lyon Node"] = 4.42f, ["[Spain] Barcelona Link"] = 4.76f, ["[Italy] Milan Depot"] = 6.34f, ["[Italy] Rome Dispatch"] = 8.26f },
            ["[Switzerland] Zurich Station"] = new() { ["[Italy] Milan Depot"] = 3.04f, ["[Germany] Munich Hub"] = 3.45f, ["[Italy] Turin Storage"] = 3.67f, ["[France] Lyon Node"] = 4.67f, ["[France] Marseille Terminal"] = 7.1f },
            ["[Norway] Oslo Gate"] = new() { ["[Sweden] Stockholm Node"] = 5.8f, ["[Denmark] Copenhagen Hub"] = 6.92f, ["[Germany] Hamburg Port"] = 10.39f, ["[Germany] Berlin Yard"] = 11.57f, ["[Netherlands] Amsterdam Dock"] = 12.45f },
            ["[Portugal] Lisbon Center"] = new() { ["[Spain] Madrid Central"] = 7.24f, ["[Spain] Barcelona Link"] = 14.78f, ["[France] Marseille Terminal"] = 19.1f, ["[France] Paris HQ"] = 20.71f, ["[France] Lyon Node"] = 23.06f },
        };
        private List<string> nodeList;

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider adding the 'required' modifier or declaring as nullable.
        public Form1()
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider adding the 'required' modifier or declaring as nullable.
        {
            InitializeComponent();
            GenerateDepots();
        }

        private void InitializeComponent()
        {
            this.btnSolve = new Button();
            this.cmbStartDepot = new ComboBox();
            this.lstDepots = new CheckedListBox();
            this.txtOutput = new TextBox();

            this.SuspendLayout();

            // btnSolve
            this.btnSolve.Location = new System.Drawing.Point(12, 12);
            this.btnSolve.Name = "btnSolve";
            this.btnSolve.Size = new System.Drawing.Size(100, 23);
            this.btnSolve.TabIndex = 0;
            this.btnSolve.Text = "Solve Route";
            this.btnSolve.UseVisualStyleBackColor = true;
#pragma warning disable CS8622 // Nullability of reference types in type of parameter doesn't match the target delegate (possibly because of nullability attributes).
            this.btnSolve.Click += new EventHandler(this.btnSolve_Click);
#pragma warning restore CS8622 // Nullability of reference types in type of parameter doesn't match the target delegate (possibly because of nullability attributes).

            // cmbStartDepot
            this.cmbStartDepot.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbStartDepot.FormattingEnabled = true;
            this.cmbStartDepot.Location = new System.Drawing.Point(130, 12);
            this.cmbStartDepot.Name = "cmbStartDepot";
            this.cmbStartDepot.Size = new System.Drawing.Size(200, 21);
            this.cmbStartDepot.TabIndex = 1;

            // lstDepots
            this.lstDepots.CheckOnClick = true;
            this.lstDepots.FormattingEnabled = true;
            this.lstDepots.Location = new System.Drawing.Point(12, 50);
            this.lstDepots.Name = "lstDepots";
            this.lstDepots.Size = new System.Drawing.Size(318, 124);
            this.lstDepots.TabIndex = 2;

            // txtOutput
            this.txtOutput.Location = new System.Drawing.Point(12, 190);
            this.txtOutput.Multiline = true;
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.ReadOnly = true;
            this.txtOutput.ScrollBars = ScrollBars.Vertical;
            this.txtOutput.Size = new System.Drawing.Size(760, 260);
            this.txtOutput.TabIndex = 3;

            // Form1
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.txtOutput);
            this.Controls.Add(this.lstDepots);
            this.Controls.Add(this.cmbStartDepot);
            this.Controls.Add(this.btnSolve);
            this.Name = "Form1";
            this.Text = "European TSP Solver";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private void GenerateDepots()
        {
            foreach (var depot in graph.Keys)
            {
                lstDepots.Items.Add(depot);
                cmbStartDepot.Items.Add(depot);
            }

            if (cmbStartDepot.Items.Count > 0)
                cmbStartDepot.SelectedIndex = 0;

            nodeList = graph.Keys.ToList(); 
        }


        private void btnSolve_Click(object sender, EventArgs e)
        {
            try
            {
#pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.
#pragma warning disable CS8602 // Dereference of a possibly null reference.
                string selectedStart = cmbStartDepot.SelectedItem.ToString();
#pragma warning restore CS8602 // Dereference of a possibly null reference.

                var selected = lstDepots.CheckedItems.Cast<string>()
                     .Select(s => s.ToString())
                     .ToList();
                if (!selected.Contains(cmbStartDepot.SelectedItem.ToString()))
                    selected.Insert(0, cmbStartDepot.SelectedItem.ToString());

                var distMatrix = TSP.DistanceMatrixForSubset(graph, // <‑‑ full graph
                                                             selected,
                                                             out var usedNodeList);
                var stopwatch = Stopwatch.StartNew();
                float cost = 0f;
                List<int> path = new List<int>();
                try
                {
                    (cost, path) = TSP.HeldKarp(distMatrix);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($" Exception caught:\n\n{ex.GetType()}\n{ex.Message}\n\n{ex.StackTrace}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                



                stopwatch.Stop();

                txtOutput.Clear();
                var fullRoute = TSP.ExpandTour(path, usedNodeList, graph); // full graph

                txtOutput.AppendText($"Minimum tour cost: {cost}{Environment.NewLine}{Environment.NewLine}");
                txtOutput.AppendText("Optimal drop-off order:" + Environment.NewLine);
                txtOutput.AppendText(string.Join(" -> ", path.Select(i => usedNodeList[i])));
                txtOutput.AppendText($"{Environment.NewLine}{Environment.NewLine}");

                txtOutput.AppendText("Full drive‑through path:" + Environment.NewLine);
                txtOutput.AppendText(string.Join(" -> ", fullRoute));   // the detailed route

                txtOutput.AppendText($"{Environment.NewLine}{Environment.NewLine}Time taken: {stopwatch.Elapsed.TotalMilliseconds:F2} ms");

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
